class AppUrls {
  AppUrls._();
  static const baseUrl = "https://discoverrubydemo.com/tent_trailer/api/";
  static const getCategory = "getCategory";
  static const getCategoryDetail = "getCategoryDetail";
}
