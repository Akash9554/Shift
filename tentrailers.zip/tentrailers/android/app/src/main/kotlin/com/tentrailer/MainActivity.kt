package com.tentrailer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
